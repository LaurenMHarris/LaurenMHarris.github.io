---
layout: post
title: Home They Brought Her Warrior Dead 
---

Home they brought her warrior dead:  
She nor swooned, nor uttered cry:  
All her maidens, watching, said,  
'She must weep or she will die.'  

Then they praised him, soft and low,  
Called him worthy to be loved,  
Truest friend and noblest foe;  
Yet she neither spoke nor moved.  

Stole a maiden from her place,  
Lightly to the warrior stept,  
Took the face-cloth from the face;  
Yet she neither moved nor wept.  

Rose a nurse of ninety years,  
Set his child upon her knee—  
Like summer tempest came her tears—  
'Sweet my child, I live for thee.'  

[by Alfred Tennyson](https://en.wikisource.org/wiki/Home_They_Brought_Her_Warrior_Dead)